@echo off
setlocal enabledelayedexpansion
rem Runs partition.exe on every sample input, valid ones first. Each run
rem saves NAME_output.txt next to its input; those files and readme.txt are
rem skipped here.
set EXE=%~dp0..\partition.exe
for %%f in ("%~dp0*.txt") do (
    set "name=%%~nf"
    if /i not "!name:~-7!"=="_output" if /i not "!name!"=="readme" (
        echo ===== %%~nxf
        "%EXE%" "%%f" 2
        echo.
    )
)
for %%f in ("%~dp0errors\*.txt") do (
    echo ===== errors\%%~nxf
    "%EXE%" "%%f" 2
)
rem The two files that only the 128-bit arithmetic rejects.
for %%f in ("%~dp0native_limits\*.txt") do (
    echo ===== native_limits\%%~nxf --arithmetic native
    "%EXE%" --arithmetic native "%%f" 2
)
pause
